alter session set NLS_DATE_FORMAT='yy-MM-dd';

@C:\Users\lopez\Desktop\tabd\types.sql;

@C:\Users\lopez\Desktop\tabd\tables.sql;

@C:\Users\lopez\Desktop\tabd\sequences.sql;

@C:\Users\lopez\Desktop\tabd\triggers.sql;

@C:\Users\lopez\Desktop\tabd\typebodies.sql;

@C:\Users\lopez\Desktop\tabd\package.sql;

@C:\Users\lopez\Desktop\tabd\test.sql;